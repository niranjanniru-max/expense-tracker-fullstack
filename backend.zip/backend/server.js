const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

// MongoDB Connection
mongoose.connect('mongodb+srv://expenseuser:NwgvCsEOVR9PMFFs@expenseuser.dg1etnj.mongodb.net/?appName=expenseuser');


// User Schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true }
});
const User = mongoose.model('User', userSchema);

// Expense Schema
// Expense Schema
const expenseSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  title: { type: String, required: true },
  amount: { type: Number, required: true },
  category: { type: String, required: true },
  description: { type: String, default: '' },
  date: { type: Date, default: Date.now }
});
const Expense = mongoose.model('Expense', expenseSchema);

// Middleware to verify JWT
const auth = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Access denied' });
  
  try {
    const decoded = jwt.verify(token, 'secretkey');
    req.user = decoded;
    next();
  } catch (e) {
    res.status(400).json({ error: 'Invalid token' });
  }
};

// Routes
// Register
app.post('/api/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ email, password: hashed });
    await user.save();
    res.status(201).json({ message: 'User created' });
  } catch (e) {
    res.status(400).json({ error: 'User exists' });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !await bcrypt.compare(password, user.password)) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user._id }, 'secretkey');
    res.json({ token });
  } catch (e) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get Expenses (Protected)
app.get('/api/expenses', auth, async (req, res) => {
  const expenses = await Expense.find({ userId: req.user.id });
  const total = expenses.reduce((sum, e) => sum + e.amount, 0);
  res.json({ expenses, total });
});

// Add Expense (Protected)
// Add Expense (Protected)
app.post('/api/expenses', auth, async (req, res) => {
  console.log('Received expense data:', req.body); // ADD THIS LINE
  const expense = new Expense({ ...req.body, userId: req.user.id });
  await expense.save();
  res.status(201).json(expense);
});

// Update Expense (Protected)
// Update Expense (Protected)
app.put('/api/expenses/:id', auth, async (req, res) => {
  console.log('Update expense data:', req.body); // ADD THIS LINE
  const expense = await Expense.findOneAndUpdate(
    { _id: req.params.id, userId: req.user.id },
    req.body,
    { new: true }
  );
  res.json(expense);
});

// Delete Expense (Protected)
app.delete('/api/expenses/:id', auth, async (req, res) => {
  await Expense.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
  res.json({ message: 'Deleted' });
});

app.listen(3000, () => console.log('Server running on port 3000'));
